import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdvertiseFormComponentComponent } from './advertise-form-component/advertise-form-component.component';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AdvertiseTableComponentComponent } from './advertise-table-component/advertise-table-component.component';


@NgModule({
  declarations: [
    AppComponent,
    AdvertiseFormComponentComponent,
    AdvertiseTableComponentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
