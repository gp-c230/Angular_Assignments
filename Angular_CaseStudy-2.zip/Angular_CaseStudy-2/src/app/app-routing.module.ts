import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdvertiseFormComponentComponent } from './advertise-form-component/advertise-form-component.component';
import { AdvertiseTableComponentComponent } from './advertise-table-component/advertise-table-component.component';

const routes: Routes = [
  { path:'Form', component: AdvertiseFormComponentComponent},
  { path:'Table', component: AdvertiseTableComponentComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

export const
routingComponents=[AdvertiseFormComponentComponent, AdvertiseTableComponentComponent]