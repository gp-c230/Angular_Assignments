import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-advertise-table-component',
  templateUrl: './advertise-table-component.component.html',
  styleUrls: ['./advertise-table-component.component.css']
})
export class AdvertiseTableComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
