import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvertiseTableComponentComponent } from './advertise-table-component.component';

describe('AdvertiseTableComponentComponent', () => {
  let component: AdvertiseTableComponentComponent;
  let fixture: ComponentFixture<AdvertiseTableComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdvertiseTableComponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdvertiseTableComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
