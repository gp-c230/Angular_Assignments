import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-advertise-form-component',
  templateUrl: './advertise-form-component.component.html',
  styleUrls: ['./advertise-form-component.component.css']
})
export class AdvertiseFormComponentComponent implements OnInit {

  categories = ['Furniture', 'Hardware', 'Mobile']
  constructor() { }

  ngOnInit(): void {
  }

}
