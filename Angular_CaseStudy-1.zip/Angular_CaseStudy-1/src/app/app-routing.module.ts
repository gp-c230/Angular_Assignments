import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { MenuComponent } from './menu/menu.component';
import { RestuarantComponent } from './restuarant/restuarant.component';
import { UserComponent } from './user/user.component';


const routes: Routes = [
  {path: 'Admin', component: AdminComponent},
  {path: 'Menu', component: MenuComponent},
  {path: 'Restuarant', component: RestuarantComponent},
  {path: 'User', component: UserComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
