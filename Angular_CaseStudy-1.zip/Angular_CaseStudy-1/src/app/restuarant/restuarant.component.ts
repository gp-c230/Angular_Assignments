import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-restuarant',
  templateUrl: './restuarant.component.html',
  styleUrls: ['./restuarant.component.css']
})
export class RestuarantComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
